
import streamlit as st
import pandas as pd
import plotly.express as px
import json, pathlib

st.set_page_config(page_title="FHIR-NLP Query Demo", layout="wide")

st.title("FHIR-NLP Query — Streamlit Demo")
st.markdown("Search, autocomplete, and visualize results from bundled example data.")

# Load local dataset
data_path = pathlib.Path(__file__).parent / "data" / "sample_documents.json"
docs = json.loads(data_path.read_text())

# Helper: autocomplete suggestions
def get_suggestions(q: str, limit: int = 10):
    q = q.strip().lower()
    if not q:
        return []
    s = set()
    for d in docs:
        txt = d.get("text","")
        if txt.lower().startswith(q):
            s.add(txt)
        for word in txt.split():
            if word.lower().startswith(q):
                s.add(word)
        if len(s) >= limit:
            break
    return list(s)[:limit]

# Search UI
col1, col2 = st.columns([3,1])

with col1:
    q = st.text_input("Search query", "")
    submit = st.button("Search")

    if q:
        suggestions = get_suggestions(q, limit=10)
        if suggestions:
            st.info("Suggestions: " + ", ".join(suggestions[:5]))

    if submit and q:
        with st.spinner("Searching..."):
            hits = [d for d in docs if q.lower() in d.get("text","").lower()]
            st.success(f"Found {len(hits)} result(s)")
            if hits:
                df = pd.DataFrame(hits)
                st.dataframe(df)
                if "score" in df.columns:
                    fig = px.histogram(df, x="score", nbins=10, title="Score distribution")
                    st.plotly_chart(fig, use_container_width=True)
                if "date" in df.columns:
                    df['date'] = pd.to_datetime(df['date'], errors='coerce')
                    timeline = df.groupby(df['date'].dt.date).size().reset_index(name='count')
                    if not timeline.empty:
                        fig2 = px.line(timeline, x='date', y='count', title="Results over time")
                        st.plotly_chart(fig2, use_container_width=True)
                csv = df.to_csv(index=False).encode('utf-8')
                st.download_button("Download results CSV", csv, file_name="results.csv", mime="text/csv")

with col2:
    st.header("Quick examples")
    examples = ["hypertension", "diabetes", "chest pain", "fever"]
    for ex in examples:
        if st.button(f"Run: {ex}"):
            st.session_state["q"] = ex
            st.experimental_set_query_params(q=ex)
            st.write("Type the query above and click Search.")
