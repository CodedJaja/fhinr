# FHIR-NLP Query — Streamlit Demo

This is a **Streamlit-only app** showcasing search, autocomplete, and visualization features on a sample dataset.

## Features
- Search across bundled JSON documents (`data/sample_documents.json`)
- Autocomplete suggestions from text and words
- Plotly charts (score distribution + results timeline)
- Download results as CSV
- Quick example queries

## Run locally
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy
- Push this repo to GitHub
- On [Streamlit Cloud](https://streamlit.io/cloud) or [Hugging Face Spaces](https://huggingface.co/spaces), connect your repo
- Set the app entrypoint to `app.py`
- Done! 🚀

